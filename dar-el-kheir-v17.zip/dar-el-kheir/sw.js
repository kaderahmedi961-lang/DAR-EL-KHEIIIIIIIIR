/* Dar El Kheir service worker: offline support + notification clicks.
   Never caches the API, the control panels or private uploads. */
const VER = 'dek-v15';
const SHELL = ['/offline.html', '/offline.js', '/logo-mark.png', '/icon-192.png', '/icon-512.png', '/styles.css', '/app.js'];
const NEVER = /^\/(api|admin|manage|topups|director|uploads\/private)(\/|$|\.)/;

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VER).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VER).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin !== location.origin || NEVER.test(u.pathname)) return;
  if (r.mode === 'navigate') {
    // pages: network first, offline page if the network is down
    e.respondWith(fetch(r).catch(() => caches.match('/offline.html')));
    return;
  }
  // static files: network first (so updates arrive at once), cache as fallback
  e.respondWith(fetch(r).then(res => {
    if (res.ok && /\.(js|css|png|jpg|webp|svg|webmanifest)$/.test(u.pathname)) { const c = res.clone(); caches.open(VER).then(ch => ch.put(r, c)); }
    return res;
  }).catch(() => caches.match(r)));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(l => {
    if (l.length) return l[0].focus();
    return self.clients.openWindow('/');
  }));
});
