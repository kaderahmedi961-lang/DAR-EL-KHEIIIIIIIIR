@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js first: https://nodejs.org  ^(LTS version^)
  pause
  exit /b
)
start "" cmd /c "ping -n 4 127.0.0.1 >nul & start http://localhost:3000"
echo Control panel: http://localhost:3000/admin
node server.js
pause
