#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then echo "Install Node.js first: https://nodejs.org"; read -p "Press Enter"; exit 1; fi
(sleep 2; open http://localhost:3000 2>/dev/null || xdg-open http://localhost:3000 2>/dev/null) &
echo "Control panel: http://localhost:3000/admin"
node server.js
